# Changelog
Todos los cambios notables se documentaran en este archivo.

## [1.7.4] - 2019-04-01 (SMKISO-20388)

- Ajuste para poder modificar el fichero tomcat.service

## [1.7.3] - 2018-10-31 (SMKISO-18746)

- Ajuste para poder modificar el archivo web.xml si es necesario.

## [1.7.2] - 2018-09-17 (SMKISO-17975)

- Ajuste para sessionCookieDomain en context.xml

## [1.7.1] - 2018-06-28 (SMKISO-17540)

- Añadida funcionalidad de balanceo

## [1.7] - 2018-05-25 (SIS-1508)

- Cambios de las dependencias de roles de sistemas de HTTPS a SSH debido al cambio a privado de los roles.
- Actualización de las dependencias del rol open_jdk de la 1.0 a la 1.1.

## [1.6] - 2018-02-14

- Plantilla para el context.xml, donde se define el atributo sessionCookieDomain.

## [1.5] - 2018-02-09

- Gestión correcta de los JARs adicionales, con posibilidad de actualización de versiones.

## [1.4] - 2017-10-17

- Añadida funcionalidad para arrancar tomcat en paralelo.

## [1.3] - 2017-10-17

- Añadido parámetro para configurar las variables de entorno del usuario tomcat.

## [1.2] - 2017-10-17

- Configuración por defecto para omitir la generación de informe e información de servidor ante un fallo

## [1.1] - 2017-08-18

- Eliminar el parámetro de memoria PermSize, eliminado de JAVA 8

## [1.0] - 2017-08-11

- Primera versión
