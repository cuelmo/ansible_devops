## Changelog file for sis_upgrade_centos_hots role

[1.0.0] - # First versión of the role